﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp12;

/// <summary>
/// Interaction logic for Basket.xaml
/// </summary>
public partial class Basket : Window
{
    private List<Product> products;
    public Basket(List<Product> products)
    {

    InitializeComponent();
        this.products = products;

        // Call a method to populate the UI with products and calculate total price
        UpdateBasket();
    }

    private void UpdateBasket()
    {
        // Create a stack panel to hold product details
        StackPanel productStackPanel = new StackPanel();
        productStackPanel.Margin = new Thickness(10);

        foreach (var product in products)
        {
            // Create controls for product details
            Label productNameAndPriceLabel = new Label();
            productNameAndPriceLabel.Content = $"{product.Name} - ${product.Price}";

            // Add controls to the stack panel
            productStackPanel.Children.Add(productNameAndPriceLabel);
        }

        // Create a label for the total price
        Label totalPriceLabel = new Label();
        totalPriceLabel.Content = $"Total Price: ${products.Sum(p => p.Price)}";
        totalPriceLabel.FontSize = 16;
        totalPriceLabel.FontStyle = FontStyles.Italic;

        // Add the product stack panel and total price label to the main grid
        mainGrid.Children.Add(productStackPanel);
        mainGrid.Children.Add(totalPriceLabel);
    }
}
