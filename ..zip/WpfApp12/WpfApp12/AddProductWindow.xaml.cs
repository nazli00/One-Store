﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace WpfApp12
{
    public partial class AddProductWindow : Window
    {
        public Product NewProduct { get; set; }

        public AddProductWindow()
        {
            InitializeComponent();
            NewProduct = new Product();
        }

        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.gif;*.bmp|All Files|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                NewProduct.Photo = new BitmapImage(new Uri(openFileDialog.FileName));

                productImage.Source = NewProduct.Photo;
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            NewProduct.Name = productNameTextBox.Text;

            if (double.TryParse(priceTextBox.Text, out double parsedPrice))
            {
                NewProduct.Price = parsedPrice;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }
    }
}
