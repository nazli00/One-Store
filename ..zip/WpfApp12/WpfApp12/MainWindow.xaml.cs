﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfApp12;

public partial class MainWindow : Window
{

    private List<Product> store = new List<Product>();

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Add(object sender, RoutedEventArgs e)
    {
        var addProductWindow = new AddProductWindow();

        bool? result = addProductWindow.ShowDialog();

        if (result == true)
        {
            Product newProduct = addProductWindow.NewProduct;

            store.Add(newProduct);
            GenerateProductStackPanel(newProduct);
        }
    }

    private void AddToBasket(Product product)
    {
        MessageBox.Show($"Added {product.Name} to the basket!");
    }
    private void GenerateProductStackPanel(Product product)
    {
        StackPanel productPanel = new StackPanel();
        productPanel.Margin = new Thickness(10);
        productPanel.Background = Brushes.LightGray;

        Label productNameAndPriceLabel = new Label();
        productNameAndPriceLabel.Height = 30;
        productNameAndPriceLabel.Width = 170;
        productNameAndPriceLabel.Content = $"{product.Name} - ${product.Price}";

        Button addToBasketButton = new Button();
        addToBasketButton.Height = 30;
        addToBasketButton.Width = 30;
        addToBasketButton.VerticalAlignment = VerticalAlignment.Bottom;
        addToBasketButton.HorizontalAlignment = HorizontalAlignment.Right;
        addToBasketButton.Margin = new Thickness(10);

        Image buttonImage = new Image();
        buttonImage.Source = new BitmapImage(new Uri("pack://application:,,,/images/download (7).jpeg"));
        buttonImage.Width = buttonImage.Source.Width;
        buttonImage.Height = buttonImage.Source.Height;
        addToBasketButton.Content = buttonImage;

        Image ProductImage = new Image();
        ProductImage.Source = product.Photo;
        ProductImage.Width = ProductImage.Source!.Width ;
        ProductImage.Height = ProductImage.Source.Height ;

        productPanel.Children.Add(new Image() { Source = ProductImage.Source, Width = buttonImage.Width, Height = buttonImage.Height });
        productPanel.Children.Add(productNameAndPriceLabel);
        productPanel.Children.Add(addToBasketButton);

        storeDataPanel.Children.Add(productPanel);
        storeDataPanel.Height += productPanel.Height;
    }
    // In MainWindow.xaml.cs
    private void basket_Click(object sender, RoutedEventArgs e)
    {
        Basket basketWindow = new Basket(store);
        basketWindow.ShowDialog();
    }

}
